// Add interactive features and form handling
document.addEventListener('DOMContentLoaded', function () {
    // Your code here

    // Example: Handle form submission
    const contactForm = document.getElementById('contactForm');
    contactForm.addEventListener('submit', function (event) {
        event.preventDefault();
        // Your form submission logic goes here
    });
});
document.addEventListener('DOMContentLoaded', function () {
    // Image slider functionality
    const slider = document.querySelector('.slider');
    let counter = 1;

    setInterval(() => {
        slider.style.transition = 'transform 0.5s ease-in-out';
        slider.style.transform = 'translateX(' + (-counter * 100) + '%)';
        counter++;

        if (counter === slider.children.length) {
            counter = 1;
            setTimeout(() => {
                slider.style.transition = 'none';
                slider.style.transform = 'translateX(' + (-counter * 100) + '%)';
            }, 500);
        }
    }, 3000);
});
